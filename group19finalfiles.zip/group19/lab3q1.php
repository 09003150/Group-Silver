<?php
    if(!isset($_POST['submit']))  {
	?>	
	
	<?php } else{
		printf("<p>Hello %s </p>\n", htmlspecialchars($_POST['name']));"
		}
?>