  <?php
	$dbh=$pdo;
	# Prepare the SELECT Query
	$stmt = $dbh->prepare("SELECT TaskID, UserID, TaskTitle, TaskDesc, 
                         ClaimDeadline, SubmissionDeadline FROM taskstable WHERE StatusID ='1' AND taskID IN 
						 (SELECT taskID from tagids join usertags on tagids.TagID = usertags.tagid 
							WHERE usertags.userid = '$login_session')
							");
	# Execute the SELECT Query
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$taskID = $row['TaskID'];
		$userID = $row['UserID'];
		$title = $row['TaskTitle'];
		$description = $row['TaskDesc'];
		$claimDeadline = $row['ClaimDeadline'];
		$submissionDeadline = $row['SubmissionDeadline'];
		printf("
				<tr>
					<td> %s </td>
					<td> %s </td>
					<td> %s </td>
					<td> %s </td>
					<td> %s </td>
					<td> %s </td>
					<td><a href='silvertaskdetails.php?task_id=%s' title='Details'>Details</a></td>
					<td><a href='silverclaimacceptance.php?task_id=%s' title='Claim'>Claim</a></td>
					<td><a href='silverflagtask.php?task_id=%s' title='Flag'>Flag</a></td>
				</tr>", $taskID, $title, $userID, $description, $claimDeadline, $submissionDeadline,$taskID,$taskID,$taskID);
	}
 
 ?>