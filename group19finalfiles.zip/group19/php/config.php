<?php
   define('DB_SERVER', 'localhost:3306');
   define('DB_USERNAME', 'group19');
   define('DB_PASSWORD', 'yard-WORE-ONLY-UPON');
   define('DB_DATABASE', 'group19');

 
   $dbh = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   	$options = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_EMULATE_PREPARES => false
	);
	
   $pdo = new PDO("mysql:host=localhost; dbname=group19", "group19", "yard-WORE-ONLY-UPON");
?>