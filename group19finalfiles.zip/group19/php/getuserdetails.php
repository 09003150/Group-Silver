  <?php
	$dbh=$pdo;
	# Prepare the SELECT Query
	$stmt = $dbh->prepare("SELECT UserID, UserPoints, UserDiscipline FROM usertable
							WHERE userid = '$login_session'
							");
						
	# Execute the SELECT Query
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$points = $row['UserPoints'];
		$disc = $row['UserDiscipline'];
		printf("
				<tr>
					<td> %s </td>
					<td> %s </td>
				</tr>
		", $points, $disc);
	}
	

 ?>