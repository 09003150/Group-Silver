<?php
	$dbh=$pdo;
		$stmt_tags = $dbh->prepare("SELECT tagnames.tagname FROM tagnames JOIN usertags ON tagnames.tagid = usertags.tagid
							WHERE usertags.userid = '$login_session'
							");	
		printf("<br></br><b>My Tags</b><br></br>");
		$stmt_tags->execute();
	while($row = $stmt_tags->fetch(PDO::FETCH_ASSOC)){
		$tags = $row['tagname'];
	}






?>