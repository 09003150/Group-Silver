<?php
   include('config.php');
   session_start();
   
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($dbh,"select userid from usertable where userid = '$user_check' ");
   $ses_sql_uname = mysqli_query($dbh,"select firstname from usertable where userid = '$user_check' ");
   $ses_sql_upoints = mysqli_query($dbh,"select userpoints from usertable where userid = '$user_check' ");
   $ses_sql_banstatus = mysqli_query($dbh,"select banstatus from usertable where userid = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   $row_uname = mysqli_fetch_array($ses_sql_uname,MYSQLI_ASSOC);
   $row_upoints = mysqli_fetch_array($ses_sql_upoints,MYSQLI_ASSOC);
   $row_bstatus = mysqli_fetch_array($ses_sql_banstatus, MYSQLI_ASSOC);
   
   $login_session = $row['userid'];
   $login_session_uname = $row_uname['firstname'];
   $login_session_upoints = $row_upoints['userpoints'];
   $login_ban_status = $row_bstatus['banstatus'];
   
   if($login_ban_status=='1'){
	   header("location: silveryouarebanned.php");
   }
	  
   if(!isset($_SESSION['login_user'])){
      header("location: silverlogin.php");
   }
   
   //Here we check if any tasks have expired their claim deadlines or submission deadlines
   //claim deadlines
   $query1 = "UPDATE taskstable SET StatusID = '2' WHERE StatusID ='1' AND ClaimDeadline < cast(now() AS DATE)";
   $result1 = mysqli_query($dbh,$query1);
   if($result1==false){
	   printf("error: %s\n", mysqli_error($dbh));
   } else{
	   echo "done.";
   
   //submission deadlines
	//get claimantID
	$claimIDsql = "SELECT claimedtasks.claimID
	FROM taskstable inner JOIN claimedtasks 
	ON taskstable.TaskID = claimedtasks.taskID 
	WHERE taskstable.StatusID ='5' AND taskstable.SubmissionDeadline < cast(now() as date)";
	
	$result2 = mysqli_query($dbh, $claimIDsql) or die(mysqli_error($dbh));
	$rows=array();
	while($row = mysqli_fetch_array($result2)){
		$rows[]=$row['claimID'];
	}
	
	//Use the claimant ID obtained to decrease his userpoints in usertable
	$query2 = "UPDATE usertable SET userpoints = userpoints - 30 WHERE userid IN (" .implode(",",$rows). ")";
	   $result3 = mysqli_query($dbh,$query2);
   if($result3==false){
	   printf("error: %s\n", mysqli_error($dbh));
   } else{
	   echo "done3.";
   }
      }
?>