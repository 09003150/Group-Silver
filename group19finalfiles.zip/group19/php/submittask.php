<?php

    /* Attempt MySQL server connection.

    server with default setting (user 'root' with no password) */
     

    // Check connection

    if($dbh === false){

        die("ERROR: Could not connect. " . mysqli_connect_error());

    }


    // attempt insert query execution
	
		
        
		if(isset($_POST["submit"])) {
		$taskIDhref = $_GET['task_id'];
		$TaskFileFormat =     mysqli_real_escape_string($dbh, $_REQUEST['TaskFileFormat']);

		//organising directory path for new completedfile
		$temp = explode(".", $_FILES["completedfile"]["name"]);
		$completedname = $taskIDhref . '.' . end($temp);
		
		
    
		//    <!-----completedfile checks----->
		$uploadOk = 1;
		$imageFileType = pathinfo(basename($_FILES["completedfile"]["name"]),PATHINFO_EXTENSION);

		// Check file size
		if ($_FILES["completedfile"]["size"] > 500000) {
			echo "Sorry, your file is too large.<br></br>";
			$uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "doc" && $imageFileType != "docx" && $imageFileType != "rtf" && $imageFileType != "txt" ) {
			echo "Sorry, only DOC, DOCX, RTF & TXT files are allowed., The file you uploaded is a " . $imageFileType . "file. <br></br>";
			$uploadOk = 0;
		}
				//Make sure filetypes match
		if($imageFileType != $TaskFileFormat) {
			echo "Sorry, Filetype does not match selected filetype.<br></br>";
			$uploadOk = 0;
		}
		
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.<br></br>";
		// if everything is ok, try to upload file
		} else {
			if (move_uploaded_file($_FILES["completedfile"]["tmp_name"], "completed_files/" . $completedname)) {
				echo "The file ". basename( $_FILES["completedfile"]["name"]). " has been uploaded as Task " .$taskIDhref . ".<br></br>";
			} else {
				echo "Sorry, there was an error uploading your file.<br></br>";
				
			}
		}
		
		
		
			if($uploadOk==1){
			$sql_update = "UPDATE taskstable SET statusID='6' WHERE taskid = $taskIDhref";
			$result = mysqli_query($dbh , $sql_update);
			echo "File uploaded. The record has been altered.";
			if (!$result) {
			throw new Exception(mysqli_error($dbh)."[ $sql_update]");
			}
		//<------------If the file uploads aren't , we delete the row created ------->

		if($uploadOk==0){
			$sql_update = "UPDATE taskstable SET statusID='3' WHERE taskid = $taskIDhref";
			$result = mysqli_query($dbh , $sql_update);
			echo "File not uploaded. The record has been removed.";
			if (!$result) {
			throw new Exception(mysqli_error($dbh)."[ $sql_update]");
			}			
		
		}
	echo "Records Uploaded successfully.<br></br>";
	} else{
        echo "ERROR: Could not able to execute $sql_update. " . mysqli_error($dbh);

			}		
		}
?>