	<?php
	include('php/session.php');
	?>
	<?php
	
	$claimIDsql = "SELECT claimedtasks.claimID
	FROM taskstable inner JOIN claimedtasks 
	ON taskstable.TaskID = claimedtasks.taskID 
	WHERE taskstable.StatusID ='6' AND taskstable.SubmissionDeadline < cast(now() as date)";
	
	$result2 = mysqli_query($dbh, $claimIDsql) or die(mysqli_error($dbh));
	$rows=array();
	while($row = mysqli_fetch_array($result2)){
		$rows[]=$row['claimID'];
	}
	
	$query2 = "UPDATE usertable SET userpoints = userpoints - 30 WHERE userid IN (" .implode(",",$rows). ")";
	   $result3 = mysqli_query($dbh,$query2);
   if($result3==false){
	   printf("error: %s\n", mysqli_error($dbh));
   } else{
	   echo "done3.";
   }


	?>