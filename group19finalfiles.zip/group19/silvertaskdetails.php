<?php
include('php/session.php');
?>


<html><head>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">
    <title>Task Details </title>

    <script type="text/javascript" src="script.js"></script>

    <link rel="stylesheet" href="style.css" type="text/css" media="screen">
<script>try {  for(var lastpass_iter=0; lastpass_iter < document.forms.length; lastpass_iter++){    var lastpass_f = document.forms[lastpass_iter];    if(typeof(lastpass_f.lpsubmitorig)=="undefined"){      if (typeof(lastpass_f.submit) == "function") {        lastpass_f.lpsubmitorig = lastpass_f.submit;        lastpass_f.submit = function(){          var form = this;          try {            if (document.documentElement && 'createEvent' in document)            {              var forms = document.getElementsByTagName('form');              for (var i=0 ; i<forms.length ; ++i)                if (forms[i]==form)                {                  var element = document.createElement('lpformsubmitdataelement');                  element.setAttribute('formnum',i);                  element.setAttribute('from','submithook');                  document.documentElement.appendChild(element);                  var evt = document.createEvent('Events');                  evt.initEvent('lpformsubmit',true,false);                  element.dispatchEvent(evt);                  break;                }            }          } catch (e) {}          try {            form.lpsubmitorig();          } catch (e) {}        }      }    }  }} catch (e) {}</script></head>
<body>
<div id="art-page-background-simple-gradient">
    </div>
    <div id="art-page-background-glare">
        <div id="art-page-background-glare-image"></div>
    </div>
    <div id="art-main">
        <div class="art-Sheet">
            <div class="art-Sheet-tl"></div>
            <div class="art-Sheet-tr"></div>
            <div class="art-Sheet-bl"></div>
            <div class="art-Sheet-br"></div>
            <div class="art-Sheet-tc"></div>
            <div class="art-Sheet-bc"></div>
            <div class="art-Sheet-cl"></div>
            <div class="art-Sheet-cr"></div>
            <div class="art-Sheet-cc"></div>
            <div class="art-Sheet-body">
                <div class="art-Header">
                    <div class="art-Header-jpeg"></div>
                    <div class="art-Logo">
                        <h1 id="name-text" class="art-Logo-name"><a href="#"> Silver Proofreading.com</a></h1>
                        <div id="slogan-text" class="art-Logo-text">Best proofreading website in the world</div>
                    </div>
                </div>
                <div class="art-nav">
                	<div class="l"></div>
                	<div class="r"></div>
                	<ul class="art-menu">
                		<li>
                			<a href="silverindex.html" class=" active"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
                		</li><li><span class="art-menu-separator"></span></li>
                		<li>
                			<a href="silverprofile.php"><span class="l"></span><span class="r"></span><span class="t">Profile</span></a>

                		</li><li><span class="art-menu-separator"></span></li>		
                		<li>
                			<a href="silverlogout.php"><span class="l"></span><span class="r"></span><span class="t">Logout</span></a>
                		</li>
                	</ul>
                </div>
                <div class="art-contentLayout">
                    <div class="art-content">
                        <div class="art-Post">
                            <div class="art-Post-body">
                        <div class="art-Post-inner">
                                        <div class="art-PostMetadataHeader">
                                            <h2 class="art-PostHeader">
                                                Task Details
                                            </h2>
                                        </div>
                                        <div class="art-PostContent">

  
  <?php
	include('php/gettaskdetails.php');
 ?>

 <!-- Here we create a link to the previewfile -->
<?php
include('php/printpreviewlink.php');
 ?>
 
 <!-- Here we create a link to the mainfile, if the login user created the task, claimed the task, or is a moderator-->

 <?php
 //Here we get the taskID and userID from that
$dbh=$pdo;
//statement to get ownerID from taskid
$stmt1 = $dbh->prepare("SELECT UserID FROM taskstable where taskID ='$taskIDhref'");
$ownerID = $stmt1 -> execute();



//statement to get claimantID from taskid, if claimed
$stmt2= $dbh->prepare("SELECT claimedtasks.ClaimID,  
						FROM claimedtasks inner JOIN taskstable on claimedtasks.TaskID = taskstable.taskID 
						WHERE taskstable.TaskID ='$taskIDhref'");
$claimantID = $stmt2 -> execute();



if($login_session_upoints >= 40 || $stmt1->fetchColumn(0)==$login_session ||  $stmt2 ->fetchColumn(0)==$login_session){
include('php/printmainfilelink.php');	
echo"<br></br>";

 if($login_session_upoints >= 40){
	$claimant= $stmt2->fetchColumn(0) ;
printf("

<b> Moderator Actions</b>
<a href='silverbanuser.php?user_id=%s' title='banuser'>Ban User?</a>
<a href='silverunpublishtask.php?task_id=%s' title='unpublish'>Unpublish Task?</a>
<br><br>
", $stmt2->fetchColumn(0), $taskIDhref);
}

$stmt3= $dbh->prepare("SELECT UserID, statusID FROM taskstable where taskID ='$taskIDhref'");
$result3 = $stmt3 -> execute();

if($stmt3->fetchColumn(1) == 6 && $stmt3->fetchColumn(1) == $login_session){
include('php/printcompletedfilelink.php');
}

}
 ?>
 
 
 
 
 
 
 
    
                                        


    
                                        
	
                                                
                                        </div>
                                        <div class="cleared"></div>
                        </div>
                        
                        		<div class="cleared"></div>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
                <div class="cleared"></div><div class="art-Footer">
                    <div class="art-Footer-inner">
                        
                        <div class="art-Footer-text">
                            <p><a href="#">About this Website</a> | <a href="#">Terms of Use</a> | <a href="#">Contact us</a>
                                | <a href="#">Privacy Statement</a><br>
                                Copyright © 2017 ---. All Rights Reserved.</p>
                        </div>
                    </div>
                    <div class="art-Footer-background"></div>
                </div>
        		<div class="cleared"></div>
            </div>
        </div>
        <div class="cleared"></div>
        <!-- Creative Commons License - Please keep designers creative credit unmodified and intact  -->
        <p class="art-page-footer"><a href="http://webjestic.net/templates/">CSS Template</a> designed by <a href="http://webjestic.net">webJestic</a></p>
    </div>
    


</body>

</html>